let initialState = {
    popularMovies: [],
    topRatedMovies: [],
    upcomingMovies: []
}

const movieReducer = (state = initialState, action) => {
    let {type, payload} = action;
    switch(type) {
        case "GET_MOVIE_SUCCESS" :
            return {
                ...state,
                popularMovies: payload.popularMovies,
                topRatedMovies: payload.topRatedMovies,
                upcomingMovies: payload.upcomingMovies
            };

            default:
                return {...state,}
    }


  return (
    <div>movieReducer</div>
  )
}

export default movieReducer