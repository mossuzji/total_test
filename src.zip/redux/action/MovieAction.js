import api from "../api";

/* 
    리덕스 미들웨어
    - 두개의 개체 사이에서 원만히 통신할 수 있도록 돕는 역할
    - 리덕스 미들웨어는 action 과 reducer 사이의 중간자 역할
    - action(함수) - middleware - reducer - store
    - 비동기 처리 작업을 간편하게 가능 
*/
const API_KEY = process.env.REACT_APP_API_KEY

function getMovies() {
    return async(dispatch) => {
        try {
            dispatch({type:"GET_MOVIES_REQUEST"})

            const popularMoiveApi = api.get(`/movie/popular?api_key=${API_KEY}&language=en-US&page=1`)
            const topRatedApi = api.get(`/movie/top_rated?api_key=${API_KEY}&language=en-US&page=1`)
            const upcomingApi = api.get(`/movie/upcoming?api_key=${API_KEY}&language=en-US&page=1`)

            let [popularMovies, topRatedMovies, upcomingMovies] = await Promise.all([
                popularMoiveApi, 
                topRatedApi, 
                upcomingApi
            ]);
    
            dispatch({
                type: "GET_MOVIE_SUCCESS",
                payload: {
                    popularMovies: popularMovies.data,
                    topRatedMovies: topRatedMovies.data,
                    upcomingMovies: upcomingMovies.data
                }    
            })
        } catch(error) {
            //에러 핸들링하는 곳
            dispatch({type: "GET_MOVIES_FAILURE"})

        }
    }
}

export const MovieAction = {
    getMovies
}