import React, {useEffect} from 'react'
import Banner from '../component/Banner'
import { useDispatch, useSelector } from 'react-redux'
import { MovieAction } from '../redux/action/MovieAction'

const Home = () => {
const dispatch = useDispatch();
const {popularMovies, topRatedMovies, upCommingMovie} = useSelector((state)=> state.movie)
useEffect(() => {
    dispatch(MovieAction.getMovies)
}, [])

  return (
    <div>
        {/* <Banner movie ={popularMovies.results[1]}/> */}
        <div className='contents'>
            <h2>What's Popular</h2>
            <h2>Top Rated Movies</h2>
            <h2>Upcoming Movies</h2>
        </div>
    </div>
  )
}

export default Home