import React from 'react'

const MovieDetail = () => {
  return (
    <div><h1>MovieDetail</h1></div>
  )
}

export default MovieDetail