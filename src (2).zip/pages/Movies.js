import React from 'react'

const Movies = () => {
  return (
    <div><h1>Movies</h1></div>
  )
}

export default Movies